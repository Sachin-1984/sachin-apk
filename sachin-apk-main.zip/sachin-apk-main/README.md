name: Build APK
on:
  push:
    branches: [main]
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Unzip project
        run: unzip -q sachin-apk-project.zip -d project
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'
      - name: Build debug APK
        working-directory: project
        run: gradle assembleDebug --no-daemon --stacktrace
      - uses: actions/upload-artifact@v4
        with:
          name: Sachin-APK
          path: project/app/build/outputs/apk/debug/app-debug.apk
